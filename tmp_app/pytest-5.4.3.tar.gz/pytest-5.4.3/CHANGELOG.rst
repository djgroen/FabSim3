=========
Changelog
=========

The pytest CHANGELOG is located `here <https://docs.pytest.org/en/latest/changelog.html>`__.

The source document can be found at: https://github.com/pytest-dev/pytest/blob/master/doc/en/changelog.rst
