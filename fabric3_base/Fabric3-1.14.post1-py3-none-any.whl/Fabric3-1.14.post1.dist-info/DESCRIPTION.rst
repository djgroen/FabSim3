
Fabric3 is a fork of `Fabric <http://fabfile.org>`_ to provide compatability
with Python 3.4+. The port still works with Python 2.7.

The goal is to stay 100% compatible with the original Fabric.  Any new releases
of Fabric will also be released here.  Please file issues for any differences
you find. Known differences are `documented on github
<https://github.com/mathiasertl/fabric/>`.

To find out what's new in this version of Fabric, please see `the changelog
<http://fabfile.org/changelog.html>`_ of the original Fabric.

For more information, please see the Fabric website or execute ``fab --help``.


